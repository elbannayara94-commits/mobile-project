# MOB1 Task 1 – Android Applications

This repository contains five separate Android application modules implemented with Kotlin and Jetpack Compose:

1. Birthday Card
2. Task Done
3. Quadrant
4. Article
5. Business Card

## Open and run
1. Install Android Studio on a computer.
2. Open this project folder (the folder containing `settings.gradle.kts`).
3. Allow Gradle sync to finish.
4. Select one module at a time from the run configuration:
   `birthdaycard`, `taskdone`, `quadrant`, `article`, or `businesscard`.
5. Run on an Android emulator or connected Android device.

Each module is a separate installable Android app and contains one main screen.
The apps follow the device's system Light/Dark theme setting.

## Important
GitHub is for storing and submitting source code; it does not compile or run Android apps.
This starter project has not been built on your device. A successful Gradle sync/build in Android Studio is still required before submission.
Replace the sample student details in the Business Card app with your own approved details before submitting.
