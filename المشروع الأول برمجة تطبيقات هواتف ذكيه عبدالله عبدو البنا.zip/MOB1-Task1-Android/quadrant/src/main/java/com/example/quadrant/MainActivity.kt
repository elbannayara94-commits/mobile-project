package com.example.quadrant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF315C78),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5E8F5),
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onBackground = Color(0xFF17212B)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC9E5),
    onPrimary = Color(0xFF102A3A),
    primaryContainer = Color(0xFF29485D),
    background = Color(0xFF101820),
    surface = Color(0xFF18232D),
    onBackground = Color(0xFFEAF1F6)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppContent()
                }
            }
        }
    }
}


@Composable
fun AppContent() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(Modifier.weight(1f)) {
            QuadrantPanel("Text composables", "Displays text and follows the screen theme.", Color(0xFFEADDFF), Modifier.weight(1f))
            QuadrantPanel("Image composables", "Creates visual elements for an app.", Color(0xFFD0BCFF), Modifier.weight(1f))
        }
        Row(Modifier.weight(1f)) {
            QuadrantPanel("Row composables", "Arranges elements horizontally.", Color(0xFFB69DF8), Modifier.weight(1f))
            QuadrantPanel("Column composables", "Arranges elements vertically.", Color(0xFFF6EDFF), Modifier.weight(1f))
        }
    }
}
@Composable
fun QuadrantPanel(title: String, description: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().background(color).padding(16.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Color(0xFF241A35))
        Spacer(Modifier.height(12.dp))
        Text(description, textAlign = TextAlign.Center, color = Color(0xFF241A35))
    }
}
