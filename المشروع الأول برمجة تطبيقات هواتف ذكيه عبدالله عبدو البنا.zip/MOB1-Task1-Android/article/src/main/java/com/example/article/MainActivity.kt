package com.example.article

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF315C78),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5E8F5),
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onBackground = Color(0xFF17212B)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC9E5),
    onPrimary = Color(0xFF102A3A),
    primaryContainer = Color(0xFF29485D),
    background = Color(0xFF101820),
    surface = Color(0xFF18232D),
    onBackground = Color(0xFFEAF1F6)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppContent()
                }
            }
        }
    }
}


@Composable
fun AppContent() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(220.dp).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center) {
            Text("📖", fontSize = 76.sp)
        }
        Column(Modifier.padding(24.dp)) {
            Text("EDUCATION  •  3 MIN READ", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("The Beauty of Learning", fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
            Spacer(Modifier.height(16.dp))
            Text("Learning helps us discover new ideas, understand the world, and build skills for the future. Every small step adds to our knowledge.", fontSize = 17.sp, lineHeight = 27.sp, color = MaterialTheme.colorScheme.onBackground)
        }
    }
}
