package com.example.business.card

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF315C78),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5E8F5),
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    onBackground = Color(0xFF17212B)
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFF9CC9E5),
    onPrimary = Color(0xFF102A3A),
    primaryContainer = Color(0xFF29485D),
    background = Color(0xFF101820),
    surface = Color(0xFF18232D),
    onBackground = Color(0xFFEAF1F6)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) DarkColors else LightColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppContent()
                }
            }
        }
    }
}


@Composable
fun AppContent() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(104.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center) {
            Text("AB", color = MaterialTheme.colorScheme.onPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Text("Your Full Name", fontSize = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text("Information Systems Student", color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
        Spacer(Modifier.height(36.dp))
        HorizontalDivider()
        ContactLine("☎", "059 XXX XXXX")
        ContactLine("✉", "your.email@example.com")
        ContactLine("⌖", "Al-Aqsa University")
    }
}
@Composable
fun ContactLine(icon: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(18.dp))
        Text(value, fontSize = 16.sp)
    }
}
